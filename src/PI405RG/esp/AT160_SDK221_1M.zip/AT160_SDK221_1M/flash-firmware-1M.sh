#!/bin/sh
# Flashing ESP using esptool: https://github.com/themadinventor/esptool

echo Make sure that GPIO0 is connected to ground

#
# https://www.espressif.com/en/products/hardware/esp8266ex/resources
# AT version:1.6.0.0(Feb  3 2018 12:00:06)
# SDK version:2.2.1(f42c330)
# compile time:Feb 12 2018 16:31:26
# 

/work/mcu/esptool/esptool.py --port /dev/ttyUSB0  write_flash 0x00000 boot.bin 0x01000 user1.1024.new.2.bin 0x7E000 blank.bin 0xFB000 blank.bin 0xFC000 esp_init_data_default.bin 0xFE000 blank.bin 
