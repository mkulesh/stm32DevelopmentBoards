#!/bin/sh
# Flashing ESP using esptool: https://github.com/themadinventor/esptool

echo Make sure that GPIO0 is connected to ground

#
# ESP8266_NONOS_SDK_V2.0.0_16_08_10
# https://bbs.espressif.com/viewtopic.php?f=46&t=2451
# AT version:1.3.0.0(Jul 14 2016 18:54:01)
# SDK version:2.0.0(656edbf)
# 

/work/mcu/esptool/esptool.py --port /dev/ttyUSB0  write_flash 0x00000 eagle.flash.bin 0x10000 eagle.irom0text.bin 0x78000 blank.bin 0x7A000 blank.bin 0x7C000 esp_init_data_default.bin 0x7E000 blank.bin 

